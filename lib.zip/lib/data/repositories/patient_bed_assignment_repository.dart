import 'dart:convert';
import 'package:app_geriatrico/data/models/patient_bed_assignment_model.dart';
import 'package:app_geriatrico/services/api_services.dart';

class PatientBedAssignmentRepository {
  final ApiService api;
  PatientBedAssignmentRepository(this.api);

  /// Todas las asignaciones (incluye paciente y cama con habitación)
  Future<List<PatientBedAssignment>> getAll() async {
    final res = await api.get('/patient-bed-assignments');
    final List data = jsonDecode(res.body);
    return data.map((e) => PatientBedAssignment.fromJson(e)).toList();
  }

  /// Asignar un paciente a una cama
  Future<PatientBedAssignment> assign(int patientId, int bedId) async {
    final res = await api.post('/patient-bed-assignments', {
      'patient_id': patientId,
      'bed_id': bedId,
    });
    final body = jsonDecode(res.body);
    return PatientBedAssignment.fromJson(body['data']);
  }

  /// Dar de alta al paciente de la cama (libera la cama)
  Future<void> release(int assignmentId) async {
    await api.delete('/patient-bed-assignments/$assignmentId');
  }
}
